using Microsoft.AspNetCore.Mvc;
using Backend.Interfaces;
using Backend.Services;
using Backend.DTOs;
using Microsoft.AspNetCore.Authorization;

namespace Backend.Controllers
{
    [Authorize(Roles = "Admin,HRManager")]
    [ApiController]
    [Route("api/[controller]")]
    public class LeaveRequestController : ControllerBase
    {
        private readonly ILeaveRequestService _leaveRequestService;

        public LeaveRequestController(ILeaveRequestService leaveRequestService)
        {
            _leaveRequestService = leaveRequestService;
        }

        [HttpGet]
        public async Task<IActionResult> GetAll()
        {
            var leaveRequests = await _leaveRequestService.GetAllAsync();
            return Ok(leaveRequests);
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetById(int id)
        {
            var leaveRequest = await _leaveRequestService.GetByIdAsync(id);
            if (leaveRequest == null) return NotFound();
            return Ok(leaveRequest);
        }

        [HttpPost]
        public async Task<IActionResult> Create(CreateLeaveRequestDto dto)
        {
            var createdLeaveRequest = await _leaveRequestService.CreateAsync(dto);
            return CreatedAtAction(nameof(GetById), new { id = createdLeaveRequest.Id }, createdLeaveRequest);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> Update(int id, CreateLeaveRequestDto dto)
        {
            var updatedLeaveRequest = await _leaveRequestService.UpdateAsync(id, dto);
            if (updatedLeaveRequest == null) return NotFound();
            return Ok(updatedLeaveRequest);
        }

        [HttpPut("{id}/approve")]
        public async Task<IActionResult> Approve(int id)
        {
            var success = await _leaveRequestService.ApproveAsync(id);
            if (!success) return NotFound();
            return Ok();
        }

        [HttpPut("{id}/reject")]
        public async Task<IActionResult> Reject(int id)
        {
            var success = await _leaveRequestService.RejectAsync(id);
            if (!success) return NotFound();
            return Ok();
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            var success = await _leaveRequestService.DeleteAsync(id);
            if (!success) return NotFound();
            return NoContent();
        }
    }
}