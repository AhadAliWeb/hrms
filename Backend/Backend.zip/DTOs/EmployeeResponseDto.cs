

namespace Backend.DTOs
{
        public class EmployeeResponseDto
    {
        public int Id { get; set; }
        public string FirstName { get; set; } = null!;
        public string LastName { get; set; } = null!;
        public string Email { get; set; } = null!;
        public string Phone { get; set; } = null!;
        public decimal Salary { get; set; }
        public bool IsActive { get; set; }
        public string DepartmentName { get; set; } = null!;
        public string DesignationTitle { get; set; } = null!;
    }
}